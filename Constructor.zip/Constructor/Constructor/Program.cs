﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Car Pamilerincar = new Car("Toyota", "Camry", 2006, "Black");
            

            Console.WriteLine("{0} {1} {2} {3}",
                Pamilerincar.Make, 
                Pamilerincar.Model, 
                Pamilerincar.Year, 
                Pamilerincar.Color);

            Car Paulcar = new Car("Honda", "Civic", 2007, "Red");

            Console.WriteLine("{0} {1} {2} {3}",
               Paulcar.Make,
               Paulcar.Model,
               Paulcar.Year,
               Paulcar.Color);

            Car Moklitecar = new Car("Benz", "E Class", 2014, "Green");

            Console.WriteLine("{0} {1} {2} {3}",
              Moklitecar.Make,
              Moklitecar.Model,
              Moklitecar.Year,
              Moklitecar.Color);

            Console.ReadLine();
        }
    }

    class Car
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string Color { get; set; }

        public Car(string modelMake, string modelModel, int modelYear, string modelColor)
        {
            Make = modelMake;
            Model = modelModel;
            Year = modelYear;
            Color = modelColor;
        }
    }
}
